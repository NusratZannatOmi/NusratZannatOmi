<!DOCTYPE html>
<html lang="en">
  
<head>
    <title>GFG- Store Data</title>
</head>
  
<body>
    <center>
        <h1>Registration for Candidate</h1>
  
        <form action="insert.php" method="post">
              
<p>
                <label for="firstName">ID:</label>
                <input type="text" name="ID" id="ID">
            </p>              
<p>
                <label for="firstName">Name:</label>
                <input type="text" name="first_name" id="firstName">
            </p>
  
  
  
              
              
<p>
                <label for="lastName">Email:</label>
                <input type="text" name="last_name" id="lastName">
            </p>
  
  
  
              
              
<p>
                <label for="Gender">Phone:</label>
                <input type="text" name="gender" id="Gender">
            </p>
  
  
              
              
              
<p>
                <label for="Address">City:</label>
                <input type="text" name="address" id="Address">
            </p>
  
  
  
              
            <input type="submit" value="Submit">
        </form>
    </center>
</body>
  
</html>