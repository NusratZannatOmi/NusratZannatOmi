<html>
<head>
  <title>NDC Company</title>
  <h1 ><img src="companylogo.jpg" alt="company" width="300" height="300"></h1>
</head>
<body> 
<table align="center">

<?php
echo "Welcome to Xcoursion Company";
?>
<tr>
<td><a href="REGISTRATION.php"> Registration </a></td>
<td><a href="LOGIN.php"> Login </a></td>
<td><a href="PUBLIC HOME.php"> Home </a></td>
</tr>
</table>
<?php include 'footer.php';?>
 </body>
</html>