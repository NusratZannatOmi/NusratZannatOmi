-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2021 at 11:15 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Id` int(4) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Date of Birth` varchar(20) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Salary` int(40) NOT NULL,
  `Hired Date` varchar(50) NOT NULL,
  `Contact Number` int(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Id`, `Name`, `Gender`, `Date of Birth`, `Designation`, `Salary`, `Hired Date`, `Contact Number`, `Address`, `Email`) VALUES
(1839, 'Nahidul Islam', 'Male', '17-08-1999', 'Gateman', 40000, '17-05-2020', 1303074910, '504/1,west kafrul,dhaka-1206', 'nahinulislam01@gmail.com'),
(1840, 'Sadia Ara', 'Female', '10-08-1999', 'Nurse', 50000, '17-09-2019', 1701037691, '605/1,north kaful,dhaka 1206', 'sadiaara00@gmail.com'),
(1841, 'Nibir Ahmed', 'Male', '15-05-2002', 'designation', 60000, '10-08-2020', 1779687356, 'k-45,khilkhet,dhaka 1238', 'nibirahmed@gmail.com'),
(1842, 'Fatihatul Islam', 'Female', '12-05-2001', 'servent', 20000, '25-09-2017', 1515602057, '604/1,monipur,dhaka 1206', 'fatihaislam@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
